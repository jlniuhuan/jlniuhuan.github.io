---
layout: links     # 必须
title: <center><b>友链</b></center>   # 可选，这是友链页的标题
body: [article]
meta:
  header: [title]
  footer: false
links:
  - group: 技术大佬
    icon: fas fa-user-tie
    items:
    - name:     # 博客名
      avatar:   # 头像链接
      url:      # 博客链接
      backgroundColor: '#3E74C9' # 卡片背景颜色
      textColor: '#fff'  # 卡片文字颜色
      tags:     # 标签
      - 标签1
      - 标签2
  - group: 施工中
    icon: fas fa-user-tie
    items:
    - name:     # 博客名
      avatar:   # 头像链接
      url:      # 博客链接
      backgroundColor: '#3E74C9' # 卡片背景颜色
      textColor: '#fff'  # 卡片文字颜色
      tags:     # 标签
      - 标签1
      - 标签2
---
