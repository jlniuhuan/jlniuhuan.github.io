---
layout: list
type: mylist
index: true
title: <center><b>列表</b></center>
body: [article]
meta:
  header: [title]
  footer: false
---
